#!/bin/bash
/opt/src/jwtcrack $@
