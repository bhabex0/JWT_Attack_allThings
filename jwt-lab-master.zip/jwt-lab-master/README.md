This is a JSON Web Token challenge lab. Feel free to clone it or visit it at https://jwt-lab.herokuapp.com/

If you want to get it working on your own computer/server.


git clone https://github.com/h-a-c/jwt-lab

sudo snap install ruby --classic

cd jwt-lab

bundle install 

rails db:migrate

rails s


You might have some issues with bundle install but nothing a google search can't help with.
